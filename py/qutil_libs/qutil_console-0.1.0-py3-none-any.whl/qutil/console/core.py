def hello():
    return "Hello from qutil.console"
